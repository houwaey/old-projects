package com.hibernate.dao.impl;

import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.hibernate.dao.ICustomerDao;
import com.hibernate.dao.common.AbstractHibernateDao;
import com.hibernate.model.Customer;

@Repository
public class CustomerDao extends AbstractHibernateDao<Customer> implements ICustomerDao {

	public CustomerDao() {
		super();
		setClazz(Customer.class);
	}

	@Override
	public boolean create(Set<Customer> customers) {
		Session session = getCurrentSession();
		Transaction tx = session.beginTransaction();
		if (customers.size() > 0) {
			try {
				for (Customer customer : customers) {
					session.persist(customer);
				}
				tx.commit();
				return true;
			} catch (Exception e) {
				logger.error(e.getMessage());
				tx.rollback();
				return false;
			} finally {
				session.close();
			}
		}
		return false;
	}
	
}

package com.hibernate.service.impl;

import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hibernate.dao.ICustomerDao;
import com.hibernate.dao.common.IOperations;
import com.hibernate.model.Customer;
import com.hibernate.service.ICustomerService;
import com.hibernate.service.common.AbstractHibernateService;

@Service
@Transactional
public class CustomerService extends AbstractHibernateService<Customer> implements ICustomerService {

	@Autowired
	private ICustomerDao dao;
	
	public CustomerService() {
		super();
	}
	
	@Override
	protected IOperations<Customer> getDao() {
		return dao;
	}

	@Override
	public boolean create(Set<Customer> customers) {
		return dao.create(customers);
	}

}

package com.hibernate.service.common;

import java.io.Serializable;
import java.util.List;

import com.hibernate.dao.common.IOperations;

public abstract class AbstractService<T extends Serializable> implements IOperations<T> {

	public T findOneById(long id) {
		return getDao().findOneById(id);
	}

	public List<T> findByKeyVal(String key, String value) {
		return getDao().findByKeyVal(key, value);
	}

	public List<T> findAll() {
		return getDao().findAll();
	}

	public boolean create(T entity) {
		return getDao().create(entity);
	}

	public boolean update(T entity) {
		return getDao().update(entity);
	}

	public boolean delete(T entity) {
		return getDao().delete(entity);
	}

	public boolean deleteById(long entityId) {
		return getDao().deleteById(entityId);
	}

	protected abstract IOperations<T> getDao();
	
}
package com.hibernate.controllers;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.hibernate.configuration.HibernateConfiguration;
import com.hibernate.configuration.SpringMvcInitializer;
import com.hibernate.configuration.SpringWebConfiguration;
import com.hibernate.model.Customer;
import com.hibernate.model.Vendor;
import com.hibernate.service.ICustomerService;
import com.hibernate.service.IVendorService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { SpringWebConfiguration.class, HibernateConfiguration.class, SpringMvcInitializer.class })
public class TestUnit {
	
	@Autowired
	private IVendorService vendorService;
	
	@Autowired
	private ICustomerService customerService;

	@Test
	public void list() {
		Vendor vendor = vendorService.findOneById(4);
		System.out.println(vendor);
	}
	
//	@Test
	public void list2() {
		Customer customer = customerService.findOneById(1);
		System.out.println(customer);
	}
	
//	@Test
	public void test() {
		Set<Customer> customers = new HashSet<Customer>();
		
		Customer c1 = new Customer();
		c1.setCustomerName("customer 3");
		customers.add(c1);
		
		Customer c2 = new Customer();
		c2.setCustomerName("customer 4");
		customers.add(c2);
		
		Vendor v = new Vendor();
		v.setVendorName("vendor 2");
		v.setCustomers(customers);
		
		vendorService.create(v);
		
	}
	
//	@Test
/*	public void test2() {
		Vendor v = new Vendor();
		v.setVendorName("vendor1 m2o");
		
		Set<Customer> customers = new HashSet<Customer>();
		Customer c1 = new Customer();
		c1.setCustomerName("customer1 m2o");
		c1.setVendor(v);
		customers.add(c1);
		
		Customer c2 = new Customer();
		c2.setCustomerName("customer2 m2o");
		c2.setVendor(v);
		customers.add(c2);
		
		customerService.create(customers);
		
	}*/
	
	
	
	
	
	
}

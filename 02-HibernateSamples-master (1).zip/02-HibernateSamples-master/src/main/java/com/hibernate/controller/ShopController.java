package com.hibernate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hibernate.common.ResponseObject;
import com.hibernate.model.Vendor;
import com.hibernate.service.IVendorService;

@RestController
public class ShopController {

	@Autowired
	private IVendorService vendorService;
	
	@GetMapping("/vendor/{id}")
	public ResponseObject<Vendor> findVendorById(@PathVariable("id") long id) {
		Vendor vendor = vendorService.findOneById(id);
		if (vendor == null) {
			return new ResponseObject<Vendor>(HttpStatus.NOT_FOUND);
		}
		return new ResponseObject<Vendor>(vendor, HttpStatus.OK);
	}
	
}

package com.spring.dao;

import com.spring.model.User;

public interface UserDao {

	User findById(int id);
	
	User findBySSO(String sso);
	
}


package com.hibernate.dao;

import java.util.Set;

import com.hibernate.dao.common.IOperations;
import com.hibernate.model.Customer;

public interface ICustomerDao extends IOperations<Customer> {

	boolean create(Set<Customer> customers);
	
}

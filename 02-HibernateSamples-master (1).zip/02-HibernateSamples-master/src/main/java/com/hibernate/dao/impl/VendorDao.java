package com.hibernate.dao.impl;

import org.springframework.stereotype.Repository;

import com.hibernate.dao.IVendorDao;
import com.hibernate.dao.common.AbstractHibernateDao;
import com.hibernate.model.Vendor;

@Repository
public class VendorDao extends AbstractHibernateDao<Vendor> implements IVendorDao {

	public VendorDao() {
		super();
		setClazz(Vendor.class);
	}
	
}

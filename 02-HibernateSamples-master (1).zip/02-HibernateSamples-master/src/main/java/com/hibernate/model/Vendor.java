package com.hibernate.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tblvendors")
public class Vendor implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "vid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long vendorId;
	
	@Column(name = "vname")
	private String vendorName;
	
	@OneToMany(fetch = FetchType.EAGER, targetEntity = Customer.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "venid", referencedColumnName = "vid")
	private Set<Customer> customers;

	public Long getVendorId() {
		return vendorId;
	}

	public void setVendorId(Long vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public Set<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}

	@Override
	public String toString() {
		String c = "";
		for (Customer customer : customers) {
			c += customer;
		}
		return "Vendor [vendorId=" + vendorId + ", vendorName=" + vendorName + ", customers=" + c + "]";
	}
	
}
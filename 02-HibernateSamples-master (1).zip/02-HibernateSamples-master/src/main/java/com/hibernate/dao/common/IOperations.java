package com.hibernate.dao.common;

import java.io.Serializable;
import java.util.List;

public interface IOperations<T extends Serializable> {

	T findOneById(final long id);
	
	List<T> findByKeyVal(final String key, final String value);
	
	List<T> findAll();
	
	boolean create(final T entity);

	boolean update(final T entity);
	
	boolean delete(final T entity);
	
	boolean deleteById(final long entityId);
	
}
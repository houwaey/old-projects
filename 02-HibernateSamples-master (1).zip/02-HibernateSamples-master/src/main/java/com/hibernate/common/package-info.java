/**
 * 
 */
/**
 * @author Houwaey
 *
 */
package com.hibernate.common;

package com.hibernate.handler;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

@Component
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
	
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {
		
		Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
		
		for (GrantedAuthority authority : authorities) {
			if (authority.getAuthority().equalsIgnoreCase("ROLE_USER")) {
				redirectStrategy.sendRedirect(request, response, "/home");
			} else if (authority.getAuthority().equalsIgnoreCase("ROLE_DBA")) {
				redirectStrategy.sendRedirect(request, response, "/db");
			} else if (authority.getAuthority().equalsIgnoreCase("ROLE_ADMIN")) {
				redirectStrategy.sendRedirect(request, response, "/admin");
			} else {
				throw new IllegalStateException();
			}
		}
		
	}

}
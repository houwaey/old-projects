package com.hibernate.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hibernate.dao.IVendorDao;
import com.hibernate.dao.common.IOperations;
import com.hibernate.model.Vendor;
import com.hibernate.service.IVendorService;
import com.hibernate.service.common.AbstractHibernateService;

@Service
@Transactional
public class VendorService extends AbstractHibernateService<Vendor> implements IVendorService {

	@Autowired
	private IVendorDao dao;
	
	public VendorService() {
		super();
	}
	
	@Override
	protected IOperations<Vendor> getDao() {
		return dao;
	}

}

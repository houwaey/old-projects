package com.hibernate.service;

import com.hibernate.dao.common.IOperations;
import com.hibernate.model.Vendor;

public interface IVendorService extends IOperations<Vendor> {

}

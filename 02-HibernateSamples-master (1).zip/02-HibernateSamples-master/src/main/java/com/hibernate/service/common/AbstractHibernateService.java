package com.hibernate.service.common;

import java.io.Serializable;
import org.springframework.transaction.annotation.Transactional;

import com.hibernate.dao.common.IOperations;

@Transactional
public abstract class AbstractHibernateService<T extends Serializable> 
	extends AbstractService<T> 
	implements IOperations<T> {
	
	/** 
	 * Will automatically use all the superclass' (AbstractService) methods
	 * 
	 * */
	
}
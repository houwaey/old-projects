package com.hibernate.service;

import com.hibernate.dao.ICustomerDao;
import com.hibernate.dao.common.IOperations;
import com.hibernate.model.Customer;

public interface ICustomerService extends ICustomerDao, IOperations<Customer> {

}

package com.hibernate.dao;

import com.hibernate.dao.common.IOperations;
import com.hibernate.model.Vendor;

public interface IVendorDao extends IOperations<Vendor> {

}
